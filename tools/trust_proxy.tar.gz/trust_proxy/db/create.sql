# msg_type: 0 income msg, 1 outgoing msg
create table messages(time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, msg_id text, type int, instance_uuid text, method text, para text, response text, policy text,count int);
