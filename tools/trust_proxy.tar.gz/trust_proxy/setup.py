import sys

#from distutils.core import setup
#from distutils.extension import Extension
from setuptools import setup
#ext_modules = [Extension("rfoo.marsh", ["rfoo/marsh.pyx"])]


setup(
    name = 'tproxy',
    version = '0.1',
    description = 'Logging all income messages',
    author = 'Yuqiong Sun',
    author_email = 'yus138@cse.psu.edu',
    url = 'www.cse.psu.edu/~yus138',
    license = 'BSD',
    packages = ['tproxy','ncproxy'],
    entry_points = {
        'nova.hooks': [
                'console_output = tproxy.hooks.ConsoleOutput',
                'rpc_call_log = tproxy.hooks.RPCLog'
        ]
    }
    #scripts = ['scripts/rconsole'],
    #cmdclass = {'build_ext': build_ext},
    #ext_modules = ext_modules
)



