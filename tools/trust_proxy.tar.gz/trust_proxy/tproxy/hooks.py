# Author: Yuqiong Sun <yus138@cse.psu.edu>
# Function: Log RPC meesages into database

import nova.hooks
from nova.openstack.common import log as logging
import os.path
import sqlite3
import pickle
try:
    import json
except ImportError:
    import simplejson as json
import tempfile
import os
from subprocess import call
import rfoo
import base64

#LOG = logging.getLogger(nova.compute.manager)


def get_count(uuid, db_path='/var/log/nova/db/tproxy.db'):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("select count(msg_id) from messages where instance_uuid = '%s'"%uuid)
    count = c.fetchone()
    conn.commit()
    conn.close()
    # Monolithicly increasing
    return count[0] + 1



# For test
class ConsoleOutput(object):


    def pre(self, *args, **kwargs):
        fname = open('/var/log/nova/test.log','w')
        fname.write("begin")
        self.log = fname

    def post(self, rv, *args, **kwargs):
        self.log.write("end")
        self.log.write(rv)
        self.log.close()

# Class handle income RPC messages
class RPCLog(object):

    def __init__(self):
        self.fname = '/var/log/nova/hook.log'
        self.db_path = '/var/log/nova/db/tproxy.db'

    def pre(self, args, kwargs, f):
        if not os.path.isfile(self.fname):
            self.log_file = open(self.fname, 'w')
        else:
            self.log_file = open(self.fname, 'a')


        self.log_file.write("************Income RPC Message***************\n") 
        self.log_file.write("Method: %s\n"%args[1].get('method'))
        self.log_file.write("Message_ID: %s\n"%str(args[1].get('_msg_id')))
        self.log_file.write("Args: %s\n"%str(args[1].get('args', {})))
        
        """
        # Moved to _process_data hook
        timestamp = 'CURRENT_TIMESTAMP'
        msg_id = str(args[1].get('_msg_id'))
        # Incoming msg:0 Outgoing msg:1
        msg_type = 0
        if 'instance' in args[1].get('args',{}):
            instance_uuid = str(args[1].get('args',{})['instance']['uuid'])
        else:
            instance_uuid = 'unknown'
        method = args[1].get('method')
        para = pickle.dumps(args[1].get('args', {}))
        response = 'unknown'
        policy = 'unknown'
        if instance_uuid == 'unknown':
            count = 0
        else:
            count = get_count(instance_uuid,db_path = self.db_path)
        # Write to SQLite DB instead of file
        conn = sqlite3.connect('/var/log/nova/db/tproxy.db')
        db = conn.cursor()
        db.execute("insert into messages values(CURRENT_TIMESTAMP,?,?,?,?,?,?,?,?)",(msg_id, msg_type, instance_uuid, method, "%s"%para, "%s"%response, "%s"%policy,count))
        conn.commit()
        conn.close()
        """

    def post(self, rv, args, kwargs):
       
        #self.log_file.write(str(type(rv)))
        #if rv is not None:
        #    self.log_file.write("Return: %s\n"%str(rv))
        #else:
        #    self.log_file.write("\nReturn: None\n")
        """
        self.log_file.write("****************End RPC Message************\n")
        self.log_file.close()
        """
        pass

class ExecuteLog(object):
    def __init__(self):
        self.fname="/var/log/nova/execution.log"

    def pre(self,args,kwargs, f):
        if not os.path.isfile(self.fname):
            self.log_file = open(self.fname, 'w')
        else:
            self.log_file = open(self.fname, 'a')

        if args[0]=='env':
            return

        self.log_file.write("Command:")
        run_as_root = kwargs.get('run_as_root', False)
        if run_as_root:
            self.log_file.write("(root)")
        self.log_file.write(str(args))
        para = kwargs.get('process_input',None)
        if para is not None:
            self.log_file.write("\nParameter:\n")
            self.log_file.write(str(para))
        self.log_file.write("\n")

    def post(self, rv, args, kwargs):
        if args[0]=='env':
            return
        if rv is not None and rv[0] != '':
            self.log_file.write("Return:\n")
            self.log_file.write(str(rv[0]))
            self.log_file.write("\n")
        self.log_file.close()

class FileLog(object):
    def __init__(self):
        self.fname = "/var/log/nova/execution.log"

    def pre(self,args,kwargs, f):
        if not os.path.isfile(self.fname):
            self.log_file = open(self.fname, 'w')
        else:
            self.log_file = open(self.fname, 'a')
        self.log_file.write("Method: %s\n"%f)
        for i in range(0, len(args)):
            if i == 0:
                self.log_file.write("Path: %s\n"%args[0])
                continue
            self.log_file.write("Para %s: %s "%(i, args[i]))

    def post(self,rv,args,kwargs):
        self.log_file.write("Ret: %s\n"%str(rv))
        self.log_file.close()


# Class handles income RPC messages response
class DirectCallLog(object):
    
    def __init__(self):
        self.fname = '/var/log/nova/hook.log'
        self.db_path = '/var/log/nova/db/tproxy.db'

    def pre(self,args,kwargs, f):
        
        if not os.path.isfile(self.fname):
            self.log_file = open(self.fname, 'w')
        else:
            self.log_file = open(self.fname, 'a')
        
        if 'ending' in args[2].keys():
            return

        msg = args[2]
        if 'result' in msg:
            result = msg['result']
            new_result = {}
            new_result['result'] = result
            new_result['compute_response'] = 'compute_response'
            args[2]['result'] = new_result
        #self.log_file.write("Reply is %s"%msg)
        #self.log_file.close()


    def post(self,rv, args, kwargs):
        #for each in args:
        #    self.log_file.write(str(type(each)))
        
        if 'ending' in args[2].keys():
            # Useless msg, ignore
            return
        """
        self.log_file.write("************Outgoing RPC Response Message***************\n")
        self.log_file.write("Message_ID: %s\n"%str(args[1]))
        self.log_file.write("Result: \n%s\n"%str(args[2].get('result',{})))
        self.log_file.write("****************End RPC Message************\n")
        self.log_file.close()
        """
        msg_id = str(args[1])
        response = pickle.dumps(args[2].get('result',{}))

        conn = sqlite3.connect(self.db_path)
        db = conn.cursor()
        db.execute("update messages set response=? where msg_id=?",("%s"%response, msg_id))
        conn.commit()
        conn.close()

        self.log_file.close()


class RPCCheck(object):

    def __init__(self):
        self.fname = '/var/log/nova/hook.log'
        self.db_path = '/var/log/nova/db/tproxy.db'

    def pre(self, args, kwargs, f):
        
        if not os.path.isfile(self.fname):
            self.log_file = open(self.fname, 'w')
        else:
            self.log_file = open(self.fname, 'a')

        timestamp = 'CURRENT_TIMESTAMP'
        
        #self.log_file.write("CONTEXT is %s"%args[1].to_dict())
        
        msg_id = args[1].msg_id
        # Incoming msg:0 Outgoing msg:1
        msg_type = 0
        if 'instance' in args[4]:
            instance_uuid = str(args[4]['instance']['uuid'])
        else:
            instance_uuid = 'unknown'
        method = args[3]
        para = pickle.dumps(args[4])
        response = 'unknown'
        policy = args[1].to_dict()['policy']
        
        if instance_uuid == 'unknown':
            count = 0
        else:
            count = get_count(instance_uuid,db_path = self.db_path)
        
        # Write to SQLite DB instead of file
        conn = sqlite3.connect('/var/log/nova/db/tproxy.db')
        db = conn.cursor()
        db.execute("insert into messages values(CURRENT_TIMESTAMP,?,?,?,?,?,?,?,?)",(msg_id, msg_type, instance_uuid, method, "%s"%para, "%s"%response, "%s"%policy,count))
        conn.commit()
        conn.close()
        # TODO: Put policy check here

        #self.log_file.write("policy type is %s, policy is %s"%(type(policy),policy))

        if policy is None:
            return

        policy = json.loads(policy)
        content = policy['content']
        to_verify = json.dumps(content)
        signature = policy['signature']
        pub_key = None

        try:
            c = rfoo.InetConnection().connect(host='130.203.47.43', port=50000)
            pub_key = rfoo.Proxy(c).get_key(content['uid'])
        except Exception as ex:
            #self.log_file.write("Error connecting to cloud verifier")
            return

        pub_fname = '/var/log/nova/db/%s.pub'%content['uid']
        if not os.path.exists(pub_fname):
            pub_key_file = open(pub_fname,'w')
            pub_key_file.write(pub_key)
            pub_key_file.close()

        temp_to_verify = tempfile.NamedTemporaryFile(delete=False)
        temp_to_verify
        temp_to_verify.write(to_verify)
        temp_to_verify.close()
        
        temp_sig = tempfile.NamedTemporaryFile(delete=False)
        temp_sig
        temp_sig.write(base64.b64decode(signature))
        temp_sig.close()

        ret = call(["openssl","dgst",'-sha1','-verify',pub_fname,'-signature',temp_sig.name, temp_to_verify.name])
        if ret == 0:
            self.log_file.write("Signature Verification Succeed!")
        else:
            self.log_file.write("Signagure Verification Failed!%s\n"%ret)

        os.unlink(temp_sig.name)
        os.unlink(temp_to_verify.name)

    def post(self, rv, args, kwargs):
        self.log_file.close()
